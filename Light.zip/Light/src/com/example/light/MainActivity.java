package com.example.light;
import android.annotation.SuppressLint;
import android.app.AlertDialog.Builder;
import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.light.NavDrawerListAdapter;
import com.example.light.NavDrawerItem;


@SuppressLint("NewApi") public class MainActivity extends Activity {
	private DrawerLayout mDrawerLayout;
	private ListView mDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;

	// nav drawer title
	private CharSequence mDrawerTitle;

	// used to store app title
	private CharSequence mTitle;

	// slide menu items
	private String[] navMenuTitles;
	//private TypedArray navMenuIcons;

	private ArrayList<NavDrawerItem> navDrawerItems;
	private NavDrawerListAdapter adapter;

	private Context con = null;

	private TextToSpeech mytts;
	private int bookcode = 0;
	private int bookindex = 0;
	
	private SharedPreferences scsj;
	private Editor scsjedt;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);
		con = this;




		mTitle = mDrawerTitle = getTitle();

		// load slide menu items
		// navMenuTitles =
		// getResources().getStringArray(R.array.nav_drawer_items);
		navMenuTitles = HomeFragment.books;
		// nav drawer icons from resources
		//navMenuIcons = getResources()
		//		.obtainTypedArray(R.array.nav_drawer_icons);

		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerList = (ListView) findViewById(R.id.list_slidermenu);

		makeSlideList();

		// enabling action bar app icon and behaving it as toggle button
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, // nav menu toggle icon
				R.string.app_name, // nav drawer open - description for
				// accessibility
				R.string.app_name // nav drawer close - description for
				// accessibility
				) 
		{
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(mTitle);
				// calling onPrepareOptionsMenu() to show action bar icons
				invalidateOptionsMenu();
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				// calling onPrepareOptionsMenu() to hide action bar icons
				invalidateOptionsMenu();
			}
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);

		{
			scsj = getSharedPreferences("data", Context.MODE_PRIVATE);
			scsjedt = scsj.edit();

			bookcode=scsj.getInt("bookcode", 0);
			bookindex=scsj.getInt("bookindex", 0);
			

		}
		if (savedInstanceState == null) {
			// on first time display view for first nav item
			displayView(bookindex);
		}
		{
			threadread =(new Thread(new myRunnable1()));
			threadread.start();
		}

	}
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		if (mytts != null)
			mytts.shutdown();
		
		scsjedt.putInt("bookcode", bookcode);
		scsjedt.putInt("bookindex", bookindex);
		scsjedt.commit();
		super.onDestroy();
	}
	

	/*
	 * make slide list
	 */

	private void makeSlideList() {
		// TODO Auto-generated method stub

		navDrawerItems = new ArrayList<NavDrawerItem>();

		// adding nav drawer items to array
		// Home
		for (int i = 0; i < 39; i++) {
			navDrawerItems.add(new NavDrawerItem(navMenuTitles[i], R.drawable.ic_old_testament));
		}
		for (int i = 39; i < navMenuTitles.length; i++) {
			navDrawerItems.add(new NavDrawerItem(navMenuTitles[i], R.drawable.ic_new_testament));
		}
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[0], navMenuIcons
		// .getResourceId(0, -1)));
		// // Find People
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[1], navMenuIcons
		// .getResourceId(1, -1)));
		// // Photos
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[2], navMenuIcons
		// .getResourceId(2, -1)));
		// // Communities, Will add a counter here
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[3], navMenuIcons
		// .getResourceId(3, -1), true, "22"));
		// // Pages
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[4], navMenuIcons
		// .getResourceId(4, -1)));
		// // What's hot, We will add a counter here
		// navDrawerItems.add(new NavDrawerItem(navMenuTitles[5], navMenuIcons
		// .getResourceId(5, -1), true, "50+"));

		// Recycle the typed array
		//navMenuIcons.recycle();

		mDrawerList.setOnItemClickListener(new SlideMenuClickListener());

		// setting the nav drawer list adapter
		adapter = new NavDrawerListAdapter(getApplicationContext(),
				navDrawerItems);
		mDrawerList.setAdapter(adapter);

	}

	/**
	 * Slide menu item click listener
	 * */
	private class SlideMenuClickListener implements
	ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			// display view for selected nav drawer item
			displayView(position);
			{
//				s.post(new Runnable() {
//				    @Override
//				    public void run() {
//				        int y = t.getLayout().getLineTop(40); // e.g. I want to scroll to line 40
//				        s.scrollTo(0, y);
//				    }
//				});
			}
		}
	}

	MenuItem menubtntts;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.mymenu, menu);

		/*
		 * change menu item title based on user selection.
		 */
		menubtntts = menu.findItem(R.id.itemTTS);

		switch (bookcode) {
		default:
		case 0:
			menubtntts.setTitle("KJV🔈");
			break;
		case 1:
			menubtntts.setTitle("和合本🔈");
			break;
		}
		// Associate searchable configuration with the SearchView
		SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
		SearchView searchView = (SearchView) menu.findItem(R.id.action_search)
				.getActionView();
		searchView.setSearchableInfo(searchManager
				.getSearchableInfo(getComponentName()));

		return super.onCreateOptionsMenu(menu);
	}

	/*
	 * fo(non-Javadoc)
	 * 
	 * @see android.app.Activity#onNewIntent(android.content.Intent)
	 * 
	 * 
	 * for search bar
	 */

	@Override
	protected void onNewIntent(Intent intent) {
		setIntent(intent);
		handleIntent(intent);
	}

	/**
	 * Handling intent data
	 */
	private void handleIntent(Intent intent) {
		if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
			String query = intent.getStringExtra(SearchManager.QUERY);
			// Log.e("Search text is ", query + "");

			/**
			 * Use this query to display search results like 1. Getting the data
			 * from SQLite and showing in listview 2. Making webrequest and
			 * displaying the data For now we just display the query only
			 */

			// Toast.makeText(con, "Query is " + query, 1000).show();
		}

	}



	void myttsfun() {
		//		mytts.speak(
		//		// HomeFragment.maintxtv.getText().toString()
		//		// .substring(startp, stopp),
		//				"english", TextToSpeech.QUEUE_FLUSH, null);
		String tmpstring=HomeFragment.maintxtv.getText().toString();
		for (int i = HomeFragment.TTSstartp; i < tmpstring.length(); i++)
		{
			if (('\n' != tmpstring.charAt(i))&&
					('\r' != tmpstring.charAt(i))&&
					('\b' != tmpstring.charAt(i))&&
					('\t' != tmpstring.charAt(i))&&
					('\f' != tmpstring.charAt(i))
					)
			{				
				HomeFragment.TTSstartp = i;
				break;			
			}			
		}
		if (HomeFragment.TTSstartp > tmpstring.length() - 16)
			return;
		for (int i = HomeFragment.TTSstartp+1; i < tmpstring.length(); i++)
		{
			if ('\n' == tmpstring.charAt(i))
			{				
				HomeFragment.TTSstopp = i;
				break;			
			}

		}
		if (HomeFragment.TTSstopp >= tmpstring.length())
			return;
		//Toast.makeText(con, tmpstring.substring(startp, stopp), Toast.LENGTH_SHORT).show();
		mytts.speak(tmpstring.substring(HomeFragment.TTSstartp, HomeFragment.TTSstopp), TextToSpeech.QUEUE_FLUSH, null);
		HomeFragment.TTSstartp = HomeFragment.TTSstopp + 1;//
	}
	Thread threadread=null;
	int speek=0;
	class myRunnable1 implements Runnable {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while(1==1)
			{
				if(speek==1)
				{
					if(mytts.isSpeaking())
						;
					else
						myttsfun() ;
				}

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


			}
		}
	}
	void tts_work()
	{
		if (mytts != null)
			mytts.shutdown();
		if(speek==1)
		{
			Toast.makeText(con, "TTS Stop", 1000).show();
			speek=0;
			return ;
		}
		{
			mytts = new TextToSpeech(this,
					new TextToSpeech.OnInitListener() {

				@Override
				public void onInit(int arg0) {
					// TODO Auto-generated method stub
					if (arg0 == TextToSpeech.SUCCESS) {

						switch (bookcode) {
						default:
						case 0:
							arg0 = mytts.setLanguage(Locale.US);
							break;
						case 1:
							arg0 = mytts
							.setLanguage(Locale.SIMPLIFIED_CHINESE);
							break;
						}
						if ((arg0 != TextToSpeech.LANG_COUNTRY_AVAILABLE)
								&& (arg0 != TextToSpeech.LANG_AVAILABLE)) 
							Toast.makeText(con, "!LANG_AVAILABLE",
									Toast.LENGTH_SHORT).show();

						else										
						{
							Toast.makeText(con, "TTS Start", 1000).show();
							speek=1;
						}

					}
				}
			});

			//			 mytts.setOnUtteranceProgressListener(new
			//			 UtteranceProgressListener() {
			//			
			//			 @Override
			//			 public void onDone(String arg0) {
			//			 // TODO Auto-generated method stub
			//			 myttsfun();
			//			 }
			////			
			//			 @Override
			//			 public void onError(String arg0) {
			//			 // TODO Auto-generated method stub
			//			
			//			 }
			//			
			//			 @Override
			//			 public void onStart(String arg0) {
			//			 // TODO Auto-generated method stub
			//				 myttsfun();
			//			 }
			//			
			//			 });
		}



		// startp = 0;
		// myttsfun();

		// String lCode = "en";
		//
		// if (PersistData.getStringData(con, "LNG").equalsIgnoreCase("en"))
		// {
		//
		// /*
		// * english is there already, need bangla
		// */
		// lCode = "bn";
		//
		// } else if (PersistData.getStringData(con,
		// "LNG").equalsIgnoreCase(
		// "bn"))
		//
		// {
		// lCode = "en";
		//
		// }
		//
		// changeLocateAndRestart(lCode);
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// toggle nav drawer on selecting action bar app icon/title
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action bar actions click
		switch (item.getItemId()) {
		case R.id.itemKJV:
			bookcode = 0;
			menubtntts.setTitle("KJV🔈");
			displayView(bookindex);
			// Toast.makeText(con, "Best button is clicked", 1000).show();
			return true;
		case R.id.itemCNU:
			bookcode = 1;
			menubtntts.setTitle("和合本🔈");
			displayView(bookindex);
			// Toast.makeText(con, "liked button is clicked", 1000).show();
			return true;
		case R.id.itemABT:
//			String[] dvnames = {"A","B"};
//			Builder builder = new Builder(MainActivity.this);
//			builder.setTitle("About");
//			builder.setItems(dvnames,
//					new DialogInterface.OnClickListener() {
//				public void onClick(DialogInterface dialog,
//						int which) {
//
//				}
//			});
//			builder.show();
		{

            Builder hp = new Builder(con);
            hp.setTitle("About");
            TextView hptxt1 = new TextView(con);
            hptxt1.setTextSize(20.0f);
            hptxt1.setText("\n       May God bless us,\n\n");
            hp.setIcon(R.drawable.ic_launcher);
            hp.setView(hptxt1);
            AlertDialog dl2 = hp.create();
            dl2.show();
            Window w2 = dl2.getWindow();
            LayoutParams lp2 = w2.getAttributes();
            lp2.alpha = 0.1f;
            w2.setAttributes(lp2);

		}
			return true;
		case R.id.itemTTS: 
			tts_work();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void changeLocateAndRestart(String lCode) {
		// TODO Auto-generated method stub

		Locale locale = new Locale(lCode);
		Locale.setDefault(locale);
		Configuration config = new Configuration();
		config.locale = locale;
		con.getApplicationContext().getResources()
		.updateConfiguration(config, null);



		Log.e("Storing language code ", lCode);

		/*
		 * most important, can create bug. Rememer the sequence, otherwise it
		 * won't work.
		 */

		/*
		 * Call finish method first
		 */
		MainActivity.this.finish();

		/*
		 * then call same activity to restart.
		 */

		Intent i = new Intent(con, MainActivity.class);

		startActivity(i);

	}

	/* *
	 * Called when invalidateOptionsMenu() is triggered
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// if nav drawer is opened, hide the action items

		/*
		 * active those code if you want to hide options menu when drawer is
		 * opened.
		 */
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerList);
		menu.findItem(R.id.itemTTS).setVisible(!drawerOpen);
		menu.findItem(R.id.itemTTS).setVisible(!drawerOpen);

		menu.findItem(R.id.itemTTS).setVisible(!drawerOpen);

		return super.onPrepareOptionsMenu(menu);
	}

	/**
	 * Diplaying fragment view for selected nav drawer list item
	 * */
	private void displayView(int position) {
		// update the main content by replacing fragments
		HomeFragment.TTSstartp=0;HomeFragment.TTSstopp=0;
		HomeFragment fragment = null;
		fragment = new HomeFragment(position, bookcode);
		bookindex = position;


		// switch (position) {
		// case 0:
		// fragment = new HomeFragment();
		// break;
		// case 1:
		// fragment = new FindPeopleFragment();
		// break;
		// case 2:
		// fragment = new PhotosFragment();
		// break;
		// case 3:
		// fragment = new CommunityFragment();
		// break;
		// case 4:
		// fragment = new PagesFragment();
		// break;
		// case 5:
		// fragment = new WhatsHotFragment();
		// break;
		//
		// default:
		// break;
		// }

		if (fragment != null) {
			FragmentManager fragmentManager = getFragmentManager();
			fragmentManager.beginTransaction()
			.replace(R.id.frame_container, fragment).commit();

			// update selected item and title, then close the drawer
			mDrawerList.setItemChecked(position, true);
			mDrawerList.setSelection(position);
			setTitle(navMenuTitles[position]);
			mDrawerLayout.closeDrawer(mDrawerList);

			//			fragment.maintxtv.setOnLongClickListener(new View.OnLongClickListener() {
			//			
			//			@Override
			//			public boolean onLongClick(View arg0) {
			//				// TODO Auto-generated method stub
			//				
			//				String[] dvnames = {"从头开始","从当前位置开始"};
			//				Builder builder = new Builder(MainActivity.this);
			//				builder.setTitle("TTS");
			//				builder.setItems(dvnames,
			//						new DialogInterface.OnClickListener() {
			//							public void onClick(DialogInterface dialog,
			//									int which) {
			//					
			//							}
			//						});
			//				builder.show();
			//				return false;
			//			}
			//		});
		} else {
			// error in creating fragment
			Log.e("MainActivity", "Error in creating fragment");
		}
	}

	@Override
	public void setTitle(CharSequence title) {
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls

		mDrawerToggle.onConfigurationChanged(newConfig);
	}

	/*
	 * Store machanism
	 */

}
