package com.example.light;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "NewApi", "ValidFragment" }) public class HomeFragment extends Fragment {

	public static String[] books = { "Gen", "Exo", "Lev", "Num", "Deu", "Jos",
		"Jug", "Rut", "1Sa", "2Sa", "1Ki", "2Ki", "1Ch", "2Ch", "Ezr",
		"Neh", "Est", "Job", "Psm", "Pro", "Ecc", "Son", "Isa", "Jer",
		"Lam", "Eze", "Dan", "Hos", "Joe", "Amo", "Oba", "Jon", "Mic",
		"Nah", "Hab", "Zep", "Hag", "Zec", "Mal", "Mat", "Mak", "Luk",
		"Jhn", "Act", "Rom", "1Co", "2Co", "Gal", "Eph", "Phl", "Col",
		"1Ts", "2Ts", "1Ti", "2Ti", "Tit", "Phm", "Heb", "Jas", "1Pe",
		"2Pe", "1Jn", "2Jn", "3Jn", "Jud", "Rev" };
	
	public static int bookLanguageCode=-1;
	public static int[] books_byte_index= { 819 - 819, 212761, 394168,
		529467, 717173, 872770, 979100, 1083957, 1097771, 1235438, 1348950,
		1484078, 1612273, 1731691, 1879140, 1922050, 1982896, 2014835,
		2118454, 2367054, 2455353, 2485714, 2500442, 2707155, 2944566,
		2964043, 3182102, 3247523, 3276456, 3287834, 3310962, 3314754,
		3321812, 3339101, 3346455, 3354893, 3363909, 3369987, 3404895,
		3414622, 3549083, 3634400, 3779726, 3885883, 4025219, 4079251,
		4132154, 4166452, 4184001, 4201485, 4213943, 4225555, 4235993,
		4241863, 4255534, 4265449, 4270977, 4273537, 4313420, 4326502,
		4340842, 4350086, 4363808, 4365516, 4367267, 4371046 };

	public static int TTSstartp = 0;
	public static int TTSstopp = 0;

	public static   TextView maintxtv;

	private byte[] tmparrpage = null;
	private TextToSpeech mytts;
	private RandomAccessFile fileA = null;

	private int position;
	private int file_len;
	private int tmpindex;
	private int tmpbookcode;

	SeekBar SeekBar_position;

	public HomeFragment(int index, int bookcode) {
		tmpindex = index;
		tmpbookcode = bookcode;
	}
	void myttsfun() {
		String tmpstring=HomeFragment.maintxtv.getText().toString();
		for (int i = HomeFragment.TTSstartp; i < tmpstring.length(); i++)
		{
			if (('\n' != tmpstring.charAt(i))&&
					('\r' != tmpstring.charAt(i))&&
					('\b' != tmpstring.charAt(i))&&
					('\t' != tmpstring.charAt(i))&&
					('\f' != tmpstring.charAt(i))
				)
			{				
				HomeFragment.TTSstartp = i;
				break;			
			}			
		}
		if (HomeFragment.TTSstartp > tmpstring.length() - 16)
			return;
		for (int i = HomeFragment.TTSstartp+1; i < tmpstring.length(); i++)
		{
			if ('\n' == tmpstring.charAt(i))
			{				
				HomeFragment.TTSstopp = i;
				break;			
			}
			
		}
		if (HomeFragment.TTSstopp >= tmpstring.length())
			return;
		//Toast.makeText(con, tmpstring.substring(startp, stopp), Toast.LENGTH_SHORT).show();
		mytts.speak(tmpstring.substring(HomeFragment.TTSstartp, HomeFragment.TTSstopp), TextToSpeech.QUEUE_FLUSH, null);
		HomeFragment.TTSstartp = HomeFragment.TTSstopp + 1;//
	}
	void myfun() {

		try {
			{
				while (1 == 1) {
					if (position == 0) {
						fileA.seek(position);
						break;
					}
					fileA.seek(position);
					byte tmp = fileA.readByte();
					if (tmp == 0xa) {
						fileA.seek(position + 1);
						break;
					}
					position--;
				}
			}
			// fileA.seek(position);
			// byte tmp = fileA.readByte();
			// if ((tmp & 0x80) == 0) {
			// fileA.seek(position);
			// } else if ((tmp & 0xc0) == 0xc0) {
			// fileA.seek(position);
			// } else if ((tmp & 0xc0) == 0x80) {
			// while (1 == 1) {
			// position--;
			// fileA.seek(position);
			//
			// tmp = fileA.readByte();
			//
			// if ((tmp & 0xc0) != 0x80) {
			// fileA.seek(position);
			// break;
			// }
			// }
			// }
			if(tmpbookcode==0)
			{
				if (tmpindex == books_byte_index.length - 1) {
					tmparrpage = new byte[file_len - books_byte_index[tmpindex]];
				} else {
					tmparrpage = new byte[books_byte_index[tmpindex + 1]
							- books_byte_index[tmpindex]];
				}
			}else
			{
				if (tmpindex == books_byte_index.length - 1) {
					tmparrpage = new byte[file_len - books_byte_index[tmpindex]];
				} else {
					tmparrpage = new byte[books_byte_index[tmpindex + 1]
							- books_byte_index[tmpindex]];
				}
			}
			int readlen = fileA.read(tmparrpage);
			// while (1 == 1) {
			// readlen--;
			// if (readlen <= 0)
			// break;
			// if (tmparrpage[readlen] == 0x0a) {
			// if ((readlen + 1) < 1024 * 4)
			// tmparrpage[readlen + 1] = 0;
			// break;
			// }
			//
			// }
			maintxtv.setText(new String(tmparrpage, "UTF-8"));
			maintxtv.setScrollX(0);
			maintxtv.setScrollY(0);
			// position -= arg3 / 4;
			// if (position < 0)
			// position = 0;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		if (mytts != null)
			mytts.shutdown();
		super.onDestroy();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View rootView = inflater.inflate(R.layout.fragment_home, container,
				false);
		Button btn1prev = (Button) rootView.findViewById(R.id.button1prev);
		Button btn1next = (Button) rootView.findViewById(R.id.button2next);
		btn1prev.setText("<-");
		btn1next.setText("->");
		btn1prev.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				tmpindex--;
				if (tmpindex < 0)
					tmpindex = 0;
				if (tmpbookcode == 0)
					position = HomeFragment.books_byte_index[tmpindex];
				else
					position = HomeFragment.books_byte_index[tmpindex];
				myfun();
			}
		});
		btn1next.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				tmpindex++;
				if (tmpbookcode == 0) {
					if (tmpindex == books_byte_index.length)
						tmpindex--;
					position = HomeFragment.books_byte_index[tmpindex];
				} else {
					if (tmpindex == books_byte_index.length)
						tmpindex--;
					position = HomeFragment.books_byte_index[tmpindex];
				}
				myfun();
			}
		});
		maintxtv = (TextView) rootView.findViewById(R.id.MaintxtView1);
		maintxtv.setOnLongClickListener(new View.OnLongClickListener() {

			@Override
			public boolean onLongClick(View arg0) {
				// TODO Auto-generated method stub

				String[] dvnames = {"��ͷ��ʼ","�ӵ�ǰλ�ÿ�ʼ"};
				Builder builder = new Builder( HomeFragment.this.getActivity());
				builder.setTitle("TTS");
				builder.setItems(dvnames,
						new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog,int which) {

					}
				});
				builder.show();
				return false;
			}
		});
		// SeekBar_position = (SeekBar) rootView
		// .findViewById(R.id.seekBar1_position);
		// SeekBar_position.setMax(1000);
		//
		// SeekBar_position
		// .setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
		//
		// @Override
		// public void onStopTrackingTouch(SeekBar arg0) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onStartTrackingTouch(SeekBar arg0) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onProgressChanged(SeekBar arg0, int arg1,
		// boolean arg2) {
		// // TODO Auto-generated method stub
		// // position = arg1;
		// // myfun();
		// maintxtv.setScrollX(0);
		// maintxtv.setScrollY((int) (arg1/1000.0*maintxtv.getLineCount()*1));
		// }
		// });

		try {
			if (null == fileA)
			{
				if (tmpbookcode == 0)
					fileA = new RandomAccessFile(this.getActivity()
							.getApplicationInfo().nativeLibraryDir
							+ "/libbbe.so", "r");
				else
					fileA = new RandomAccessFile(this.getActivity()
							.getApplicationInfo().nativeLibraryDir
							+ "/libbbc.so", "r");
			}
			
			file_len = (int) fileA.length();
			if(bookLanguageCode!=tmpbookcode)
			{
				bookLanguageCode=tmpbookcode;
				
				
				int seekp=file_len-1;
				byte tmp;
				do
				{
					fileA.seek(seekp);
					tmp  = fileA.readByte();
					seekp--;
				}while(tmp!='}');

				for(int index=books_byte_index.length-1;index>0;index--)
				{
					books_byte_index[index]=0;
					int pow;
					pow=1;


					do
					{
						fileA.seek(seekp);
						tmp  = fileA.readByte();
						if(('0'<=tmp)&&('9'>=tmp))
						{
							books_byte_index[index]+=(tmp-0x30)*pow;
							pow*=10;
						}
						seekp--;
					}while(tmp!=',');
					if(tmp=='{')
					{
						break;
					}

				}
				books_byte_index[0]=0;


			}
			
			// if (null == tmparr) {
			// file_len = (int) fileA.length();
			// tmparr = new byte[(int) fileA.length()];
			// fileA.read(tmparr);
			// Toast.makeText(
			// this.getActivity(),
			// this.getActivity().getApplicationInfo().nativeLibraryDir
			// + "/libbbc.so", Toast.LENGTH_LONG).show();
			//
			// }
			// maintxtv.setText(new String(tmparr, "UTF-8"));

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// if (file_len != 0)
		// SeekBar_position.setMax(file_len - 10);
		if (tmpbookcode == 0)
			position = HomeFragment.books_byte_index[tmpindex];
		else
			position = HomeFragment.books_byte_index[tmpindex];
		myfun();
		
		
		return rootView;
	}
}
